
set(target "appeveryday_day")
set(working_dir "D:/Data/Code/cpp/todo-project-enhanced/everyday_day")
set(src_and_dest_list
    "D:/Data/Code/cpp/todo-project-enhanced/everyday_day/assets/ep_app_icon.svg"
    "D:/Data/Code/cpp/todo-project-enhanced/everyday_day/build/Desktop_Qt_6_8_3_llvm_mingw_64_bit-Release/everyday_day/assets/ep_app_icon.svg"
    "D:/Data/Code/cpp/todo-project-enhanced/everyday_day/assets/ep_app_icon.ico"
    "D:/Data/Code/cpp/todo-project-enhanced/everyday_day/build/Desktop_Qt_6_8_3_llvm_mingw_64_bit-Release/everyday_day/assets/ep_app_icon.ico"

)
set(timestamp_file "D:/Data/Code/cpp/todo-project-enhanced/everyday_day/build/Desktop_Qt_6_8_3_llvm_mingw_64_bit-Release/.qt/appeveryday_day_res.txt")
