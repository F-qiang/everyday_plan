# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "Release")
  file(REMOVE_RECURSE
  "CMakeFiles\\appeveryday_day_autogen.dir\\AutogenUsed.txt"
  "CMakeFiles\\appeveryday_day_autogen.dir\\ParseCache.txt"
  "appeveryday_day_autogen"
  )
endif()
